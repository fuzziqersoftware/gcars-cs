I hate readme files. A lot of them have this fancy ASCII
artwork that makes me think the developers spent all their
time making that and not coding like they should be!

Oh well. They probably hired someone to do it. I have an
excuse for the "artwork" in the documentation - I wrote it
at my grandma's house, where I didn't have access to the
code I should have been working on.

Okay, enough ranting. This is GCARS-CS and Levine, complete
with bad documentation and all. Load gcars.dol to your
GameCube any way you'd like. Be warned: it might not work well
with SDLoad, a Max Drive Pro, or a modchip loader. But if
people could try all the loading methods for us, it would help
us create a better and more compatible program.