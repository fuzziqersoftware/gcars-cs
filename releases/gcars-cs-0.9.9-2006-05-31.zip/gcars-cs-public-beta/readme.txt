I hate readme files. A lot of them have this fancy ASCII
artwork that makes me think the developers spent all their
time making that and not coding like they should be!

Oh well. They probably hired someone to do it. I have an
excuse for the "artwork" in the documentation - I wrote it
at my grandma's house, where I didn't have access to the
code I should have been working on.

Okay, enough ranting. This is GCARS-CS and Levine, complete
with bad documentation and all. Load gcars.dol to your
GameCube any way you'd like. It should work fine with
SDLoad, the Max Drive Pro, and any modchip loader now.

The latest Control Simulator scripts can be found at
http://scripts.fuzziqersoftware.com/